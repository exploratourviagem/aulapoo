package aula_5;

public class teste {

	public static void main(String[]args) {
	
		TV obj = new TV();
		alexa obj2 = new alexa();
		
		obj.setModelo("S-5050");
		obj.setMarca("SAMSUNG");
		obj.setValor(3000.0);
		obj.Setqtdcanais(20);
		
		obj.ligar();
		Sys
		
	} 
}
