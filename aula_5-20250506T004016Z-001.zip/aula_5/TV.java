package aula_5;

public class TV extends ProdutoEletronico implements player {

	private int qtdcanais;
	
	@Override
	public void ligar() {
		System.out.println("Ligando a TV com um controle remoto");
	}
	@Override
	public void desligar() {
		System.out.println("Desligando a TV com um controle remoto");
	}
	
	public int Getqtdcanais() {
		return qtdcanais;
	}
	public void Setqtdcanais(int i) {
		this.qtdcanais = qtdcanais;
	}
	
}
