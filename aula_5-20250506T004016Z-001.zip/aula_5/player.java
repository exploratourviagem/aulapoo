package aula_5;

public interface player {

	public void play();
	public void stop();
	public void pause();
}
