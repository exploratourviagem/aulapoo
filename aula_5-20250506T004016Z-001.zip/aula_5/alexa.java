package aula_5;

public class alexa extends ProdutoEletronico{
	
	private String formato;
	
	@Override
	public void ligar() {
		System.out.println("Ligar com comando de voz");
	}
	
	@Override
	public void desligar() {
		System.out.println("Desligar com comando de voz");
	}
	
	public String getFormato() {
		return formato;
	}
	
	public void setFormato() {
		this.formato = formato;
	}

}
