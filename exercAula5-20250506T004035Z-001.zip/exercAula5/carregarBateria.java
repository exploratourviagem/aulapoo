package exercAula5;

public interface carregarBateria {

}
