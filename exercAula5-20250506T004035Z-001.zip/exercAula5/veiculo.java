package exercAula5;

public class veiculo {

}
