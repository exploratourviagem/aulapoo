package exercAula5;

public interface abastecer {

}
