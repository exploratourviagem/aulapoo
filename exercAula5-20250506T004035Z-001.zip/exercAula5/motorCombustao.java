package exercAula5;

public class motorCombustao {

}
